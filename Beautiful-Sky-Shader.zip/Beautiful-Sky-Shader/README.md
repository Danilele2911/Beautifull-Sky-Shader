# Beautiful-Sky
An edit of Sildur's vibrant shader lite 1.52

special thanks to sildur


# INSTRUCTIONS

extract the downloaded folder

move the extracted folder to the shader packs folder

run "install-shader.bat" located in the folder moved to shaderpacks

wait

run minecraft and select the shader


if you want you can delete the empty folder left in shaderpacks