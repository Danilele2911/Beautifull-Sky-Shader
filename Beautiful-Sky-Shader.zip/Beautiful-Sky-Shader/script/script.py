import shutil
import os

def sposta_file():
    # Ottieni la cartella attuale dello script
    cartella_script = os.path.dirname(os.path.abspath(__file__))
    
    # Definisci i percorsi relativi
    cartella_shader = os.path.join(cartella_script, '..', 'shader')
    cartella_shaderpacks = os.path.join(cartella_script, '..', '..')

    # Definisci i file da spostare
    file_zip = 'beautiful-sky-a4.0.zip'
    file_txt = 'beautiful-sky-a4.0.zip.txt'

    # Percorsi dei file
    percorso_file_zip = os.path.join(cartella_shader, file_zip)
    percorso_file_txt = os.path.join(cartella_shader, file_txt)

    # Percorsi di destinazione
    destinazione_zip = os.path.join(cartella_shaderpacks, file_zip)
    destinazione_txt = os.path.join(cartella_shaderpacks, file_txt)

    # Stampa i percorsi per il debug
    print(f"Percorso file zip: {percorso_file_zip}")
    print(f"Percorso file txt: {percorso_file_txt}")
    print(f"Destinazione zip: {destinazione_zip}")
    print(f"Destinazione txt: {destinazione_txt}")

    # Controlla se i file esistono
    if not os.path.isfile(percorso_file_zip):
        print(f"Il file {percorso_file_zip} non esiste.")
        return
    if not os.path.isfile(percorso_file_txt):
        print(f"Il file {percorso_file_txt} non esiste.")
        return

    # Sposta i file
    shutil.move(percorso_file_zip, destinazione_zip)
    shutil.move(percorso_file_txt, destinazione_txt)

    print(f"{file_zip} e {file_txt} sono stati spostati nella cartella {cartella_shaderpacks}.")

if __name__ == '__main__':
    sposta_file()

